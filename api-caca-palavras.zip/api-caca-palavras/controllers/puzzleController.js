function generatePuzzle(req, res) {
    const puzzle = [
      ['C', 'A', 'T'],
      ['D', 'O', 'G'],
      ['B', 'I', 'R', 'D']
    ];
  
    res.json({ puzzle });
  }
  
  module.exports = {
    generatePuzzle
  };
  
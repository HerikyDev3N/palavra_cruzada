const express = require('express');
const cors = require('cors');
const app = express();
const port = 3005;

app.use(cors());

app.get('/api/puzzle', (req, res) => {
  const puzzleSize = 20; // Tamanho do quebra-cabeça (20x20)
  const totalCells = puzzleSize * puzzleSize;

  const puzzle = Array.from({ length: puzzleSize }, () => Array(puzzleSize).fill(''));

  const words = ['CARRO', 'CASA', 'ABACAXI', 'CACHORRO', 'GATO', 'BICICLETA', 'ESCOLA', 'SOL', 'LIVRO', 'COMPUTADOR',
    'AMIGO', 'FELIZ', 'ALEGRIA', 'FLORESTA', 'MARAVILHA', 'SORRISO', 'FANTASTICO', 'NATUREZA', 'ENCANTO', 'PAZ'];

  placeWordsInPuzzle(puzzle, words);

  res.json({ puzzle });
});

function placeWordsInPuzzle(puzzle, words) {
  words.forEach(word => {
    placeWord(puzzle, word);
  });

  fillEmptyCells(puzzle);
}

function placeWord(puzzle, word) {
  const directions = [
    { row: 0, col: 1 },   // direção para a direita
    { row: 1, col: 0 },   // direção para baixo
    { row: 1, col: 1 },   // direção para baixo-direita
    { row: -1, col: 1 }   // direção para cima-direita
  ];

  const wordLength = word.length;
  const puzzleSize = puzzle.length;

  for (let i = 0; i < 100; i++) {
    const direction = directions[Math.floor(Math.random() * directions.length)];
    const startRow = Math.floor(Math.random() * puzzleSize);
    const startCol = Math.floor(Math.random() * puzzleSize);

    const endRow = startRow + direction.row * (wordLength - 1);
    const endCol = startCol + direction.col * (wordLength - 1);

    if (endRow >= 0 && endRow < puzzleSize && endCol >= 0 && endCol < puzzleSize) {
      let canPlace = true;

      for (let j = 0; j < wordLength; j++) {
        const cell = puzzle[startRow + j * direction.row][startCol + j * direction.col];
        if (cell !== '') {
          canPlace = false;
          break;
        }
      }

      if (canPlace) {
        for (let j = 0; j < wordLength; j++) {
          puzzle[startRow + j * direction.row][startCol + j * direction.col] = word[j];
        }
        return;
      }
    }
  }
}

function fillEmptyCells(puzzle) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

  puzzle.forEach(row => {
    row.forEach((cell, index, arr) => {
      if (cell === '') {
        arr[index] = alphabet[Math.floor(Math.random() * alphabet.length)];
      }
    });
  });
}

app.listen(port, () => {
  console.log(`API server is running on http://localhost:${port}`);
});
